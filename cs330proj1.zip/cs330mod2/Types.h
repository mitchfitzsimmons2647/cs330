#pragma once
#include <glm/glm.hpp>

struct Float {
	glm::vec3 Position{0.f, 0.f, 0.f};
	glm::vec3 Color{0.1f,0.1f,0.f,};
	glm::vec3 Normals{ 0.f,0.f,0.f };
	glm::vec2 UV{ 1.f,1.f };
};
struct Meshes {
	static inline std::vector<Float> cubeVertices{
		//front face
		{
			.Position = {-0.5f,0.5f,0.5f},
			.Color = {0.1f,0.1f,0.f,},
		.UV{0.f,1.f}

		},
		{
			.Position = {-0.5f,-0.5f,0.5f},
			.Color = {0.1f,0.1f,0.f,},
			.UV{0.f,0.f}
		},
		{
			.Position = {0.5f,-0.5f,0.5f},
			.Color = {0.1f,0.1f,0.f,},
			.UV{1.0f,0.f}
		},
		{
			.Position = {0.5f,0.5f,0.5f},
			.Color = {0.1f,0.1f,0.f,},
			.UV{1.f,1.f}
		},
			//right
		{
			.Position = {0.5f,0.5f,0.5f},
			.UV{0.f,1.f}
		},
		{
			.Position = {0.5f,-0.5f,0.5f},
			.UV{0.f,0.f}
		},
		{
			.Position = {0.5f,-0.5f,-0.5f},
			.UV{1.0f,0.f}
		},
		{
			.Position = {0.5f,0.5f,-0.5f},
			.UV{1.f,1.f}
		},
			//back
		{
			.Position = {0.5f,0.5f,-0.5f},
			.UV{0.f,1.f}
		},
		{
			.Position = {0.5f,-0.5f,-0.5f},
			.UV{0.f,0.f}
		},
		{
			.Position = {-0.5f,-0.5f,-0.5f},
			.UV{1.0f,0.f}
		},
		{
			.Position = {-0.5f,0.5f,-0.5f},
			.UV{1.f,1.f}
		},
			//left
		{
			.Position = {-0.5f,0.5f,-0.5f},
			.UV{0.f,1.f}
		},
		{
			.Position = {-0.5f,-0.5f,-0.5f},
			.UV{0.f,0.f}
		},
		{
			.Position = {-0.5f,-0.5f,0.5f},
			.UV{1.0f,0.f}
		},
		{
			.Position = {-0.5f,0.5f,0.5f},
			.UV{1.f,1.f}
		},
			//top
		{
			.Position = {-0.5f,0.5f,-0.5f},
			.UV{0.f,1.f}
		},
		{
			.Position = {-0.5f,0.5f,0.5f},
			.UV{0.f,0.f}
		},
		{
			.Position = {0.5f,0.5f,0.5f},
			.UV{1.0f,0.f}
		},
		{
			.Position = {0.5f,0.5f,-0.5f},
			.UV{1.f,1.f}
		},
			//bottom
		{
			.Position = {0.5f,-0.5f,0.5f},
			.UV{0.f,1.f}
		},
		{
			.Position = {0.5f,-0.5f,-0.5f},
			.UV{0.f,0.f}
		},
		{
			.Position = {-0.5f,-0.5f,-0.5f},
			.UV{1.0f,0.f}
		},
		{
			.Position = {-0.5f,-0.5f,0.5f},
			.UV{1.f,1.f}
		},

	};
	static inline std::vector<uint32_t> cubeElements{
	0, 1, 3, 1, 2, 3,
	4, 5, 7, 5, 6, 7,
	8, 9, 11, 9, 10, 11,
	12, 13, 15, 13, 14, 15,
	16, 17, 18, 17, 18, 19,
	20, 21, 23, 21, 22, 23,

	};
};