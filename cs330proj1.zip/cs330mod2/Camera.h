#pragma once
#include <glm/glm.hpp>

class Camera
{
public:
	enum class moveDirection {
		Forward,
		Backward,
		Left,
		Right

	};

	Camera(float aRatio, bool iPerspective = true);
	glm::mat4 getViewMatrix();
	glm::mat4 getProjectionMatrix();
	void setIsPerspective(bool iPerspective) { isPerspective = iPerspective; };
	void getAspectRatio(float Aratio) { aspectRatio = Aratio; }
	void moveCamera(moveDirection direction, float moveAmount);
	void rotateBy(float yaw, float pitch);
	void recalculateVectors();
	void incrementZoom(float amount);
private:
	bool isPerspective{ true };

	glm::vec3 _position{};
	glm::vec3 lookDirection{ };
	glm::vec3 upDirection{ 0.f,1.f,0.f };

	float yaw{};
	float pitch{};

	float fieldOfView{ 75.f };
	float aspectRatio{0.f};
	float nearClip{ 0.1f };
	float farClip{ 100.f };
	float zoom{ 75.f };
};

