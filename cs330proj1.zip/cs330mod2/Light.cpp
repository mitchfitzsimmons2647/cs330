#include "Light.h"
#include"Mesh.h"

Light::Light()
{
}

void Light::Init()
{
}

void Light::update(float deltaTime)
{
}

void Light::Draw(const glm::mat4& view, const glm::mat4& projection)
{

}

void Light::createShader()
{
}

void Light::createMesh()
{
}
