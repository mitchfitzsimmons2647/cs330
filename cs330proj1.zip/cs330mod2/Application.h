#pragma once

#include <string>
#include <GLAD/glad.h>
#include <GLFW/glfw3.h>
#include"Mesh.h"
#include "Shader.h"
#include "Camera.h"
class Application
{
public:
	Application(std::string WindowTitle, int width, int height);

	void Run();
private:
	bool openWindow();
	bool update();
	bool draw();
	void setupScene();
	void setupInputs();
	void mousePositionCallback(double xpos, double ypos);
private:
	std::string _applicationName;
	int _height{};
	int _width{};
	GLFWwindow* _window{};
	Camera cam;
	Mesh mesh{};
	Shader shader{};
	bool _running{ false };

	bool firstMouse = false;
	glm::vec2 lastMousePosition{ };
	glm::vec2 lookSpeed{};

	GLuint containerTexture;

	float ambientString = 0.1f;
	glm::vec3 ambientLightColor{1.f, 1.f, 1.f};
};
