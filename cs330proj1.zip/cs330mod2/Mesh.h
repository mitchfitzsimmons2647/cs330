#pragma once
#include <vector>
#include "Types.h"
#include <GLAD/glad.h>
class Mesh
{
public:
	Mesh(std::vector<Float>&& vertices, std::vector<uint32_t>&& elements);
	Mesh(std::vector<Float>&& vertices, std::vector<uint32_t>&& elements,const glm::vec3 color);
	Mesh() = default;
	void draw();
	glm::mat4 transform{ 1.f };
	void init(std::vector<Float>& vertices, std::vector<uint32_t>& elements);
private:
	uint32_t elementCount;
	GLuint VBO;
	GLuint shaderprogram;
	GLuint VAO;
	GLuint EBO;
};

