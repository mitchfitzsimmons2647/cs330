#include "Camera.h"
#include <glm/gtc/matrix_transform.hpp>
#include<algorithm>
Camera::Camera(float aRatio, bool iPerspective) : aspectRatio{ aRatio }, isPerspective{ iPerspective } 
{
	recalculateVectors();
}

glm::mat4 Camera::getViewMatrix()
{
    return glm::lookAt(_position,
		_position*lookDirection,
		upDirection);
}

glm::mat4 Camera::getProjectionMatrix()
{
	if (isPerspective)
	{
		return glm::perspective(glm::radians(fieldOfView), aspectRatio, nearClip, farClip);
	}
    return glm::ortho(-aspectRatio, aspectRatio, -1.f,1.f,nearClip,farClip);
}

void Camera::moveCamera(moveDirection direction, float moveAmount)
{
	moveAmount = .1;
	glm::vec3 MoveDirection {};
	switch (direction) {
	case moveDirection::Forward: {
		MoveDirection = lookDirection;
		break;
	}
	case moveDirection::Backward: {
		break;
		MoveDirection = -lookDirection;
	}
	case moveDirection::Left: {
		MoveDirection = glm::normalize(glm::cross(lookDirection, upDirection));
		break;
	}
	case moveDirection::Right: {
		MoveDirection = -glm::normalize(glm::cross(lookDirection, upDirection));
		break;
	}
	}
	_position += MoveDirection * moveAmount;
}

void Camera::rotateBy(float _yaw, float _pitch)
{
	yaw += _yaw;
	pitch += _pitch;

	pitch=std::clamp(pitch, -89.f, 89.f);
	recalculateVectors();
}

void Camera::recalculateVectors()
{
	lookDirection = glm::normalize(
		glm::vec3(
			std::cos(glm::radians(yaw)) * sin(glm::radians(pitch)),
			std::sin(glm::radians(pitch)),
			std::sin(glm::radians(yaw))*std::cos(glm::radians(pitch))
		)
	);
	auto rightDirection = glm::normalize(glm::cross(lookDirection, glm::vec3(0.f, 1.f, 0.f)));
	upDirection = glm::normalize(glm::cross(rightDirection, lookDirection));
}

void Camera::incrementZoom(float amount)
{
	fieldOfView += amount;
	fieldOfView = std::clamp(fieldOfView, 1.f, 75.f);
}
