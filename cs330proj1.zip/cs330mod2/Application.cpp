#include "Application.h"

#include <iostream>
#include<GLAD/glad.h>
#include<GLFW/glfw3.h>
#include "Types.h"

#include <vector>
#include <glm/gtc/matrix_transform.hpp>
#include <stb_image.h>

Application::Application(std::string WindowTitle, int width, int height) : _applicationName(WindowTitle), _width(width), _height(height),
cam {width/height,true}
{}
void Application::Run()
{
	if (!openWindow())
	{
		return;
	}
	_running = true;
	//set up the scene
	setupInputs();
	setupScene();
	while (_running)
	{
		if (glfwWindowShouldClose(_window))
		{
			_running = false;
			break;
		}
		update();
		draw();
		
	}
	glfwTerminate();
}

bool Application::openWindow()
{
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);

	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	_window = glfwCreateWindow(800, 600, "Module 4 Fitzsimmons", nullptr, nullptr);
	if (!_window)
	{
		std::cerr << "Failed to create Window" << std::endl;
		glfwTerminate();
		
	}

	glfwMakeContextCurrent(_window);
	glfwSetWindowUserPointer(_window, (void*)this);

	glfwSetFramebufferSizeCallback(_window, [](GLFWwindow* window, int width, int height) 
		{
		glViewport(0, 0, width, height);
		auto  app =reinterpret_cast<Application*>( glfwGetWindowUserPointer(window));
		app->_width = width;
		app->_height = height;
		});

	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cerr << "Failed to load GLAD" << std::endl;
		glfwTerminate();
		return false;
	}

	//glEnable(GL_DEPTH_TEST);

	//glFrontFace(GL_CCW);
	//glCullFace(GL_BACK);
	//glEnable(GL_CULL_FACE);
	return true;
}

bool Application::update()
{
	glfwPollEvents();
	return false;
}

bool Application::draw()
{
	glClearColor(0.f, 0.f, 0.f, 0.f);
	glClear(GL_COLOR_BUFFER_BIT);

	glm::mat4 view = cam.getViewMatrix();
	glm::mat4 projection = cam.getProjectionMatrix();

	glm::mat4 model = glm::mat4(1.f);


	shader.Bind();
	
	shader.SetMat4("projection", projection);
	shader.SetMat4("view", view);
	
	glBindTexture(GL_TEXTURE_2D, containerTexture);


	shader.SetMat4("model", mesh.transform);
	mesh.draw();
	
	glfwSwapBuffers(_window);
	
	return false;
}

void Application::setupScene()
{
	
	std::vector<Float> vertices =
	{
		
		//front face
		{
			.Position = {-0.5f,0.5f,0.5f},
			.Color = {0.1f,0.1f,0.f,}
		},
		{
			.Position = {-0.5f,-0.5f,0.5f},
			.Color = {0.1f,0.1f,0.f,}
		},
		{
			.Position = {0.5f,-0.5f,0.5f},
			.Color = {0.1f,0.1f,0.f,}
		},
		{
			.Position = {0.5f,0.5f,0.5f},
			.Color = {0.1f,0.1f,0.f,}
		},
		//right
	{
		.Position = {0.5f,0.5f,0.5f},
		.Color={0.1f,0.1f,0.f,}
	},
	{
		.Position = {0.5f,-0.5f,0.5f},
		.Color = {0.1f,0.1f,0.f,}
	},
	{
		.Position = {0.5f,-0.5f,-0.5f},
		.Color = {0.1f,0.1f,0.f,}
	},
	{
		.Position = {0.5f,0.5f,-0.5f},
		.Color = {0.1f,0.1f,0.f,}
	},
		//back
	{
		.Position = {0.5f,0.5f,-0.5f},
		.Color = {0.1f,0.1f,0.f,}
	},
	{
		.Position = {0.5f,-0.5f,-0.5f},
		.Color = {0.1f,0.1f,0.f,}
	},
	{
		.Position = {-0.5f,-0.5f,-0.5f},
		.Color = {0.1f,0.1f,0.f,}
	},
	{
		.Position = {-0.5f,0.5f,-0.5f},
		.Color = {0.1f,0.1f,0.f,}
	},
		//left
	{
		.Position = {-0.5f,0.5f,-0.5f},
		.Color = {0.1f,0.1f,0.f,}
	},
	{
		.Position = {-0.5f,-0.5f,-0.5f},
		.Color = {0.1f,0.1f,0.f,}
	},
	{
		.Position = {-0.5f,-0.5f,0.5f},
		.Color = {0.1f,0.1f,0.f,}
	},
	{
		.Position = {-0.5f,0.5f,0.5f},
		.Color = {0.1f,0.1f,0.f,}
	},
		//top
	{
		.Position = {-0.5f,0.5f,-0.5f},
		.Color = {0.1f,0.1f,0.f,}
	},
	{
		.Position = {-0.5f,0.5f,0.5f},
		.Color = {0.1f,0.1f,0.f,}
	},
	{
		.Position = {0.5f,0.5f,0.5f},
		.Color = {0.1f,0.1f,0.f,}
	},
	{
		.Position = {0.5f,0.5f,-0.5f},
		.Color = {0.1f,0.1f,0.f,}
	},
		//bottom
	{
		.Position = {0.5f,-0.5f,0.5f},
		.Color = {0.1f,0.1f,0.f,}
	},
	{
		.Position = {0.5f,-0.5f,-0.5f},
		.Color = {0.1f,0.1f,0.f,}
	},
	{
		.Position = {-0.5f,-0.5f,-0.5f},
		.Color = {0.1f,0.1f,0.f,}
	},
	{
		.Position = {-0.5f,-0.5f,0.5f},
		.Color = {0.1f,0.1f,0.f,}
	},
		//pyramid left
		{
			.Position = {0.f,1.f,0.f},
		.Color = {0.1f,0.1f,0.f,}
		},
		{
			.Position = {-0.5f,0.5f,-0.5f},
		.Color = {0.1f,0.1f,0.f,}
		},
		{
			.Position = {-0.5f,0.5f,0.5f},
		.Color = {0.1f,0.1f,0.f,}
		},
		// pyramid right
		{
			.Position = {0.f,1.f,0.f},
		.Color = {0.1f,0.1f,0.f,}
		},
		{
			.Position = {0.5f,0.5f,-0.5f},
		.Color = {0.1f,0.1f,0.f,}
		},
		{
			.Position = {0.5f,0.5f,0.5f},
		.Color = {0.1f,0.1f,0.f,}
		},
		// pyramid front
		{
			.Position = {0.f,1.f,0.f},
		.Color = {0.1f,0.1f,0.f,}
		},
		{
			.Position = {0.5f,0.5f,0.5f},
		.Color = {0.1f,0.1f,0.f,}
		},
		{
			.Position = {-0.5f,0.5f,0.5f},
		.Color = {0.1f,0.1f,0.f,}
		},
		// pyramid back
		{
			.Position = {0.f,1.f,0.f},
		.Color = {0.1f,0.1f,0.f,}
		},
		{
			.Position = {0.5f,0.5f,-0.5f},
		.Color = {0.1f,0.1f,0.f,}
		},
		{
			.Position = {-0.5f,0.5f,-0.5f},
		.Color = {0.1f,0.1f,0.f,}
		},
		//plane
		{
		.Position = {1.5f,-0.5f,1.5f},
		.Color = {0.1f,0.1f,0.f,}
		},
		{
		.Position = {1.5f,-0.5f,-1.5f},
		.Color = {0.1f,0.1f,0.f,}
		},
		{
		.Position = {-1.5f,-0.5f,-1.5f},
		.Color = {0.1f,0.1f,0.f,}
		},
		{
		.Position = {-1.5f,-0.5f,1.5f},
		.Color = {0.1f,0.1f,0.f,}
		}

	};

	std::vector<uint32_t> elements
	{
		//cube (the base)
		0, 1, 3, 1, 2, 3,
		4, 5, 7, 5, 6, 7,
		8, 9, 11, 9, 10, 11,
		12, 13, 15, 13, 14, 15,
		16, 17, 19, 17, 18, 19,
		20, 21, 23, 21, 22, 23,
		//pyramid (the top)
		24, 25, 26,
		27, 28, 29,
		30, 31, 32,
		33, 34, 35,
		//plane (foreground)
		36, 37, 39, 37, 38, 39

	};
	//create triange
	mesh= Mesh{ std::move(vertices), std::move(elements) };
	mesh.transform = glm::translate(mesh.transform, glm::vec3(0.0f, 3.0f, -3.0f));
	std::string unlitvertexShaderSource = R"(#version 330 core
	layout (location=0) in vec3 position;
	layout (location=1) in vec3 color;
	layout (location=2)  in vec3 normal;
	layout (location=3) in vec2 uv;

	out vec4 vertexColor;
	out vec2 texCoord;
	uniform mat4 view;
	uniform mat4 projection;
	uniform mat4 model;

	void main()
	{
		gl_Position = projection * view * model * vec4(position, 1.0);
		vertexColor = vec4(color,1.f);
		texCoord = uv;
	}
)";//gl_Position = projection * view * model * vec4(position, 1.0);
	//glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
	//glEnableVertexAttribArray(0);
	std::string unlitfragmentShaderSource = R"(#version 330 core
	out vec4 FragColor;
	in vec2 texCoord;
	 vec4 vertexColor;
	
	void main()
	{
		FragColor = vertexColor;
	}
	
)";

	std::string basicLightShaderSource = R"(#version 330 core
	out vec4 FragColor;
	in vec4 vertexColor;
	in vec2 texCoord;
	float ambientStrength = 0.1;
	vec3 lightColor = vec3(1.f,1.f,1.f);
	vec3 ambient = ambientStrength * lightColor;
	vec3 objectColor = vertexColor.xyz;
	vec3 finalColor = objectColor * ambient
	FragColor = vec4(finalColor, 1.0);
	
)";
	shader = Shader(unlitvertexShaderSource, unlitfragmentShaderSource);
	int width, height, numChannels;
	unsigned char* data = stbi_load("texture", &width, &height, &numChannels, 4);

	glGenTextures(1, &containerTexture);
	glBindTexture(GL_TEXTURE_2D, containerTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data); 
	//glTexStorage2D(GL_TEXTURE_2D, 1, GL_RGBA, width, height);
	//glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, width, height, GL_RGBA, GL_UNSIGNED_BYTE, data);
	glGenerateMipmap(GL_TEXTURE_2D);

	stbi_image_free(data);


}

void Application::setupInputs()
{
	Camera cam{800/600,true};
	glfwSetKeyCallback(_window, [](GLFWwindow* window, int key, int scancode, int action, int mods) {
		auto* app = reinterpret_cast<Application*>(glfwGetWindowUserPointer(window));
		
	if (key == GLFW_KEY_ESCAPE)
	{
		if (scancode == GLFW_PRESS)
		{
			app->_running = false;
		}
	}
	if (key == GLFW_KEY_W)
	{
		if (scancode == GLFW_PRESS)
		{
			//cam.moveCamera(Camera::moveDirection::Forward, 0.1);
		}
	}
	if (key == GLFW_KEY_S)
	{
		if (scancode == GLFW_PRESS)
		{
			//cam.moveCamera(Camera::moveDirection::Backward, 0.1);
		}
	}
	if (key == GLFW_KEY_A)
	{
		if (scancode == GLFW_PRESS)
		{
			//cam.moveCamera(Camera::moveDirection::Left, 0.1);
		}
	}
	if (key == GLFW_KEY_D)
	{
		if (scancode == GLFW_PRESS)
		{
			//cam.moveCamera(Camera::moveDirection::Right, 0.1);
		}
	}
	if (key == GLFW_KEY_Q)
	{
		if (scancode == GLFW_PRESS)
		{
			
		}
	}
	if (key == GLFW_KEY_E)
	{
		if (scancode == GLFW_PRESS)
		{
			
		}
	}
		});
	glfwSetCursorPosCallback(_window, [](GLFWwindow* window, double xpos, double ypos) {
		auto* app = reinterpret_cast<Application*>(glfwGetWindowUserPointer(window));

		});
	glfwSetScrollCallback(_window, [](GLFWwindow* window, double xOffset, double yOffset) {
		auto* app = reinterpret_cast<Application*>(glfwGetWindowUserPointer(window));
	app->cam.incrementZoom(yOffset);

		});
	glfwSetMouseButtonCallback(_window, [](GLFWwindow* window,int button, int action, int mods) {

		switch (button)
		{
			case GLFW_MOUSE_BUTTON_LEFT: 
				{
					if (action == GLFW_PRESS)
					{
						std::cout << "Left mouse button pressed.\n" ;
					}
					break;
				}
			case GLFW_MOUSE_BUTTON_MIDDLE:
			{
				if (action == GLFW_PRESS)
				{
					std::cout << "Middle mouse button pressed.\n";
				}
				break;
			}
			case GLFW_MOUSE_BUTTON_RIGHT:
			{
				if (action == GLFW_PRESS)
				{
					std::cout << "Right mouse button pressed.\n";
				}
				break;
			}
		}

		});
}

void Application::mousePositionCallback(double xpos, double ypos)
{
	if (!firstMouse)
	{
		lastMousePosition.x = xpos;
		lastMousePosition.y = ypos;
	}
	glm::vec2 moveAmount{
	xpos - lastMousePosition.x,
	ypos - lastMousePosition.y
	};
	lastMousePosition.x = xpos;
	lastMousePosition.y = ypos;

	lookSpeed = {.1f,.1f};
	cam.rotateBy(moveAmount.x*lookSpeed.x, moveAmount.y*lookSpeed.y);
}




