#include "Shader.h"
#include <iostream>
#include <GLAD/glad.h>
#include <GLFW/glfw3.h>
#include <glm/gtc/type_ptr.hpp>
Shader::Shader(const std::string& vertexSource, const std::string& fragmentSource)
{
	load(vertexSource, fragmentSource);
}




void Shader::Bind()
{
	glUseProgram(shaderprogram);
}

void Shader::SetMat4(const std::string uniformName, const glm::mat4& mat4)
{
	auto uniformLoc = getUniformLocation(uniformName);
	Bind();
	glUniformMatrix4fv(uniformLoc, 1, GL_FALSE, glm::value_ptr(mat4));
}



void Shader::load(const std::string& vertexSource, const std::string& fragmentSource)
{
	const char* vShaderCode = vertexSource.c_str();
	const char* fShaderCode = fragmentSource.c_str();
	auto vertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader, 1, &vShaderCode, nullptr);
	glCompileShader(vertexShader);

	int success;
	char infoLog[512];
	glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(vertexShader, 512, nullptr, infoLog);
		std::cerr << "Vertex Shader Compilation Error *" << infoLog;
	}
	auto fragmentShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(fragmentShader, 1, &fShaderCode, nullptr);
	glCompileShader(fragmentShader);


	glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(fragmentShader, 512, nullptr, infoLog);
		std::cerr << "Fragment Shader Compilation Error" << infoLog;
	}

	shaderprogram = glCreateProgram();
	glAttachShader(shaderprogram, vertexShader);
	glAttachShader(shaderprogram, fragmentShader);
	glLinkProgram(shaderprogram);

	glGetProgramiv(shaderprogram, GL_LINK_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(fragmentShader, 512, nullptr, infoLog);
		std::cerr << "Shader Compilation Error *" << infoLog;
	}
	glUseProgram(shaderprogram);

	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);

	
}

GLint Shader::getUniformLocation(const std::string& uniformName)
{
	return(glGetUniformLocation(shaderprogram, uniformName.c_str()));
	
}
