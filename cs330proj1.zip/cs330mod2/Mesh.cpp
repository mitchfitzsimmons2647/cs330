#include "Mesh.h"
#include <iostream>
Mesh::Mesh(std::vector<Float>&& vertices, std::vector<uint32_t>&& elements)
{
	init(vertices, elements);
}

Mesh::Mesh(std::vector<Float>&& vertices, std::vector<uint32_t>&& elements, const glm::vec3 color)
{
	for (auto& vertex : vertices)
	{
		vertex.Color = color;
	}
	init(vertices, elements);
}



void Mesh::draw()
{

	//call shader triangle draw func
	glUseProgram(shaderprogram);
	glBindVertexArray(VAO);
	//gl draw calls
	
	glDrawElements(GL_TRIANGLES, elementCount, GL_UNSIGNED_INT, nullptr);

}

void Mesh::init(std::vector<Float>& vertices, std::vector<uint32_t>& elements)
{
	glGenVertexArrays(1, &VAO);
	glGenBuffers(1, &VBO);
	glGenBuffers(1, &EBO);

	glBindVertexArray(VAO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(Float), vertices.data(), GL_STATIC_DRAW);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, static_cast<GLsizeiptr>(elements.size() * sizeof(uint32_t)), elements.data(), GL_STATIC_DRAW);

	//define vertex attributes
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Float), (void*)offsetof(Float, Position));
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Float), (void*)offsetof(Float, Color));
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, sizeof(Float), (void*)offsetof(Float, Normals));
	glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, sizeof(Float), (void*)offsetof(Float, UV));

	glEnableVertexAttribArray(0);
	glEnableVertexAttribArray(1);
	glEnableVertexAttribArray(2);
	glEnableVertexAttribArray(3);
	//shader

	elementCount = elements.size();
}
