

#include <iostream>
#include<GLAD/glad.h>
#include<GLFW/glfw3.h>
#include "Application.h"
#include <glm/glm.hpp>

int main(int args, char** argv)
{
	Application app("CS 330 Module 2 Fitzsimmons", 800, 600);
	app.Run();

	
	
	return 0;


}


