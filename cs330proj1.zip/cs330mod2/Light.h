#pragma once
#include"Mesh.h"
#include <memory>
#include "Shader.h"
class Light : public Mesh
{
public:

	Light();

	void Init() ;
	void update(float deltaTime);
	void Draw(const glm::mat4& view, const glm::mat4& projection);
private:
	void createShader();
	void createMesh();

private:
	std::shared_ptr<Shader> basicunlitShader{};
	std::shared_ptr<Mesh> basicLightMesh{};

};

