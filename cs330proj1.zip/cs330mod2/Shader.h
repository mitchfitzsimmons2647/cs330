#pragma once

#include <string>
#include <GLAD/glad.h>
#include <filesystem>
#include <glm/glm.hpp>

class Shader
{
public:
	Shader() = default;
	Shader(const std::string& vertexSource, const std::string& fragmentSource);
	
	void Bind();

	void SetMat4(const std::string uniformName, const glm::mat4 &mat4);
private:
	void load(const std::string& vertexSource, const std::string& fragmentSource);
	GLint getUniformLocation(const std::string& uniformName);
private:
	GLuint shaderprogram;
};

